package com.neupanesushant.imstask.utils

object Constants {
    const val APPLICATION_ID = "com.neupanesushant.imstask"
    const val PREFERENCES_FIRST_LAUNCH = "preferences_first_launch"
}